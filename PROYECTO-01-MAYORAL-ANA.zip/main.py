
from lifestore_file import lifestore_products as products
from lifestore_file import lifestore_sales as sales
from lifestore_file import lifestore_searches as searches
'''lifestore-searches = [id_search, id product]
lifestore-sales = [id_sale, id_product, score (from 1 to 5), date, refund (1 for true or 0 to false)]
lifestore-products = [id_product, name, price, category, stock]'''
meses=["01","02","03","04","05","06","07","08","09","10","11","12"]
usuarios=[["Javier","contrasena","Administrador"],["Patricia","pati22","Usuario"]]
print(usuarios)
#login'
cont=0
Usuario=str(input("Usuario:"))
for infousuario in usuarios:
  cont+=1
  if Usuario == infousuario[0]:
    Contrasena=str(input("Contraseña:"))
    if Contrasena==infousuario[1] and infousuario[2]=="Administrador":
      print("Bienvenido "+Usuario)
      acceso=1
      admin=1
      break
    elif Contrasena==infousuario[1] and infousuario[2]=="Usuario":
      print("Bienvenido "+Usuario)
      acceso=1
      admin=0
      break
    else:
      print("Usuario o contraseña incorrecta")
      acceso=0
      break
  elif cont<len(usuarios) :
    continue
  else:
      print("Usuario no registrado")
      acceso=0    
#fin login'  
while acceso==1:
  #obtener informacion
  info_prod=[]
  categorias=[]
  for producto in products:
    calificaciones=0
    n=0
    busquedas=0
    for sale in sales:
      if sale[1]==producto[0]:
        n+=1
        calificaciones=calificaciones+sale[2]
      suma=calificaciones
    if suma>0:
      promedio=round(suma/n,2)
    else :
      promedio=0
    for search in searches:
      if search[1]==producto[0]:
        busquedas+=1
    
    info_prod=info_prod+[[producto[0],promedio,n,busquedas,producto[3],producto[2]]]
    if producto[3] not in categorias:
      categorias.append(producto[3])
  #ordenar por reseña
  ord_reseña=[]
  f=list(info_prod)
  while f:
    maximo=f[0][1]
    lista_actual=f[0]
    for promedios in f:
      if promedios[1]>maximo:
        maximo=promedios[1]
        lista_actual=promedios
    ord_reseña.append(lista_actual[0:2])
    f.remove(lista_actual)
  #fin por reseña
  #ordenar por busquedas
  ord_busqueda=[]
  f=list(info_prod)
  while f:
    maximo=f[0][3]
    lista_actual=f[0]
    for busqueda in f:
      if busqueda[3]>maximo:
        maximo=busqueda[3]
        lista_actual=busqueda
    ord_busqueda.append([lista_actual[0],lista_actual[3],lista_actual[4]])
    f.remove(lista_actual)
  #fin ordenar por busquedas
  #ordenar por ventas
  ord_ventas=[]
  f=list(info_prod)
  while f:
    maximo=f[0][2]
    lista_actual=f[0]
    for venta in f:
      if venta[2]>maximo:
        maximo=venta[2]
        lista_actual=venta
    ord_ventas.append([lista_actual[0],lista_actual[2],lista_actual[4]])
    f.remove(lista_actual)
  #fin ordenar por ventas
    #Ordenar por categoria
  top_xcat=[]
  for categoria in categorias:
    lista=[]
    for ord_venta in ord_ventas:
      if categoria==ord_venta[2]:
        lista.append(ord_venta[0])
    top_xcat.append([categoria,lista])
#fin orden por categoria
  #ventas
  ventas_totales=0
  sale_art=[]
  for art in info_prod:
    venta_art=art[2]*art[5]
    sale_art.append(venta_art)
    ventas_totales=ventas_totales+venta_art
  #ventas mensuales
  vendido_mes=[]
  n_vendido=[]
  promedio_mensual=[]
  devoluciones=[]
  artdev=[]
  total_dev=0
  for mes in meses:
    devolucion=0
    vendido=[]
    for sale in sales:
      fecha=sale[3]
      if mes==fecha[3:5]:
        n+=1
        vendido.append(sale[1])
        if sale[4]==1:
          devolucion+=1
          total_dev+=1
          artdev.append(sale[1])
    devoluciones.append(devolucion)
    n_vendido.append(n)
    vendido_mes.append(vendido)
  ingreso_men=[]
  for vendido in vendido_mes:
    venta_mensual=0
    for art in range(1,97) :
      v=vendido.count(art)*info_prod[art-1][5]
      venta_mensual=venta_mensual+v
    ingreso_men.append(venta_mensual)
  venmes=[]
  for mes in range(1,13):
    if ingreso_men[mes-1]==0:
      promedio_mensual.append(0)
    else:
      promedio_mensual.append(round(ingreso_men[mes-1]/n_vendido[mes-1],3))
    venmes.append([mes,ingreso_men[mes-1]])
  #orden de mes de ventas
  ord_meses=[]
  while venmes:
    maximo=venmes[0][1]
    lista_actual=venmes[0]
    for month in venmes:
      if month[1]>maximo:
        maximo=month[1]
        lista_actual=month
    ord_meses.append([lista_actual[0],lista_actual[1]])
    venmes.remove(lista_actual)
  #fin de obtener informacion

  accion=int(input("""¿Qué estás buscando?
    1)Art. más vendidos.
    2)Art. menos vendidos.
    3)Art. más vendidos.(xCategoria)
    4)Art. menos vendidos.(xCategoria)
    5)Art. más buscados. 
    6)Art. menos buscados.
    7)Art. por reseña. 
    8)Ventas. 
    Ingresa el número correspondiente: """))
  if accion==1 :
    num_masv=int(input("¿Cuántos artículos más vendidos deseas ver?: "))
    print("Los "+str(num_masv)+" artículos más vendidos son: ")
    mas_vendidos=ord_ventas[:num_masv]
    print(mas_vendidos)
  elif accion==2:
    num_menv=int(input("¿Cuántos artículos menos vendidos deseas ver?: "))
    print("Los "+str(num_menv)+" artículos menos vendidos son:* ")
    menos_vendidos=ord_ventas[-num_menv:]
    print(menos_vendidos)
    print("*Los artículos se muestran de más a menos")
  elif accion==3 :
    num_masvc=int(input("¿Cuántos artículos más vendidos deseas ver?(max 5): "))
    print("El top "+str(num_masvc)+" de artículos vendidos por categoria es: ")
    for xcat in top_xcat:
      print(xcat[0])
      print(xcat[1][:num_masvc])
  elif accion==4:
    num_menvc=int(input("¿Cuántos artículos menos vendidos deseas ver?(max 5): "))
    print("El bottom "+str(num_menvc)+" de artículos vendidos por categoria es:* ")
    for xcat in top_xcat:
      print(xcat[0])
      print(xcat[1][-num_menvc:])
    print("*Los artículos se muestran de más a menos")
  elif accion==5:
    num_masb=int(input("¿Cuántos artículos más buscados deseas ver?: "))
    print("Los "+str(num_masb)+" artículos más buscados son: ")
    mas_buscados=ord_busqueda[:num_masb]
    print(mas_buscados)
  elif accion==6:
    num_menb=int(input("¿Cuántos artículos menos buscados deseas ver?:* "))
    print("Los "+str(num_menb)+" artículos menos buscados son: ")
    menos_buscados=ord_busqueda[-num_menb:]
    print(menos_buscados)
    print("*Los artículos se muestran de más a menos")
  elif accion==7:
    num_rese=int(input("¿Cuántos artículos deseas ver?: "))
    mejor_reseña=ord_reseña[:num_rese]
    peor_reseña=ord_reseña[-num_rese:]
    print("Mejores reseñas: ")
    print(mejor_reseña)
    print("Peores reseñas:* ")
    print(peor_reseña)
    print("*Los artículos se muestran de más a menos")
  elif accion==8 and admin==1:
    print("REPORTE GENERAL DE VENTAS")
    print("Ingresos totales registrados (2020): $"+str(ventas_totales))
    print("Número total de productos vendidos (2020): "+str(len(sales)))
    print("Número de devoluciones: "+str(total_dev))
    print("El mes con mayores ventas fue: "+str(ord_meses[0][0])+" con ventas de "+str(ord_meses[0][1])) 
    month=int(input("¿Deseas ver la infomación de un mes particular? Ingresa el número:(Ene-1,Feb-2,etc.): "))
    print("Número total de artículos vendidos en "+ meses[month-1]+": "+str(n_vendido[month-1]))
    print("Ingreso "+meses[month-1]+" :")
    print(ingreso_men[month-1])
    print("Compra promedio de "+meses[month-1]+" :")
    print(promedio_mensual[month-1])
    print("Devoluciones: "+ str(devoluciones[month-1]))
  else:
    print("No tiene el permiso para acceder a esa información")

  fin=input("¿Deseas finalizar?Si/No: ")
  if fin=="Si":
    acceso=0
 



  
 #fin